#define _POSIX_C_SOURCE 1
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

#define STATUS_ACCEPTED (1)
#define STATUS_WRONG_ANSWER (2)
#define STATUS_SYSTEM_ERROR (8)

void mark(int status, int score) {
    printf("%d %d\n", status, score);
    exit(0);
}

int main(void) {
    FILE *input_file = fdopen(3, "r");
    if (!input_file) {
        mark(STATUS_SYSTEM_ERROR, 0);
    }
    int sum;
    if (fscanf(input_file, "%d", &sum) != 1) {
        mark(STATUS_SYSTEM_ERROR, 0);
    }
    int a, b;
    if (scanf("%d %d", &a, &b) != 2) {
        mark(STATUS_WRONG_ANSWER, 0);
    }
    if (a + b != sum) {
        mark(STATUS_WRONG_ANSWER, 0);
    }
    mark(STATUS_ACCEPTED, 25);
}
